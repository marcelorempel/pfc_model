from .task1 import task1
from .task2 import task2
from .task3 import task3
from .task4 import task4
from .task5 import task5
from .task6 import task6

