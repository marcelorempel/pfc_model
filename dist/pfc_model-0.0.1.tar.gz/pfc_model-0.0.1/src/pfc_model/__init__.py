from importlib.metadata import version

__version__ = version(__name__)

from .cortex_setup import *



